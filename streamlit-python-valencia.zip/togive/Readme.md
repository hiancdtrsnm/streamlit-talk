# Streamlit
Para ejecutar la aplicación de streamlit, se debe ejecutar el siguiente comando en la terminal:
```bash
cd presentation
streamlit run streamlit_app.py
```

## Install dependencies
```bash
pip install -r requirements.txt
```