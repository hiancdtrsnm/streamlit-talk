import streamlit as st
import streamlit.components.v1 as components
import os

components.iframe("https://share.streamlit.io/", width=500, height=500)

"[Streamlit Cloud](https://streamlit.io/cloud)"